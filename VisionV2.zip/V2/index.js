//requiring path and fs modules
const path = require('path');
const fs = require('fs');
const chalk = require('chalk');
const Papa = require('papaparse');
// Imports the Google Cloud client library
const vision = require('@google-cloud/vision');

const credentials = require(path.join(__dirname, 'cred.json'));
// Creates a client
const client = new vision.ImageAnnotatorClient({ credentials });


async function quickstart(file) {
    // Performs label detection on the image file
    const [result] = await client.labelDetection(file);

    const labels = result.labelAnnotations;

    const ok = labels.map((label) => {

        return {
            [label.description]: label.score,
        };
    });
    return ok;
    // labels;
}

async function main() {
    const myArgs = process.argv.slice(2);

    const chunkSize = parseInt(myArgs[0])
    if (isNaN(chunkSize)) {
        console.log(chalk.redBright.bold(`Error! Chunk size must be an integer! Got "${myArgs[0]}" instead!`))
        return -1;
    }

    const directoryPath = path.join(__dirname, 'images');

    const allImagesNames = await fs.promises.readdir(directoryPath);

    const foundImagesCount = allImagesNames.length;

    console.log(chalk.greenBright.bold(`Found ${foundImagesCount} images!`))
    console.log(chalk.greenBright.bold(`Analyze images divided in ${chunkSize} chunks!`))

    let i; let j;
    let temparray;
    let count = 0;

    for (i = 0, j = foundImagesCount; i < j; i += chunkSize) {
        temparray = allImagesNames.slice(i, i + chunkSize);
        console.log(chalk.greenBright.bold(`Analyzing chunk num. ${count}!`))
        const results = [];
        const fields = ['image'];
        await Promise.all(
            temparray.map(async (file) => {
                // Do whatever you want to do with the file

                const fullPath = path.join(directoryPath, file);
                //console.log(fullPath);


                return quickstart(fullPath).then(bam => {
                    const bim = {
                        image: file,
                    };
                    bam.forEach((element) => {
                        for (let [key, value] of Object.entries(element)) {
                            //console.log(`${key}: ${value}`);
                            bim[key] = value;

                            fields.indexOf(key) === -1 && fields.push(key);
                        }
                    });

                    results.push(bim);
                })

            })
        );
        try {
            const str = Papa.unparse(results, { columns: fields });
            fs.writeFile('results-' + count + ".csv", str, 'utf8', () => console.log('ok'));
            count++;
        } catch (error) {
            console.error(error);
        }
    }
    console.log(chalk.greenBright.bold(`Finish!`))
}



main();
# USAGE:
  
## START: `npm run start <NumeberOfPhotosIn1Chunk>`

### Example:  Chunck size = 50  `npm run start 50`
<?php

namespace App\Console\Commands;

use App\Models\Category;
use App\Models\Image;
use Illuminate\Console\Command;

class Export extends Command
{
    protected $fd;
    
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'app:export';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Export data to csv';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
        // Crear fichero
        $path = storage_path('app/export/' . date('Y-m-d.H.i.s') . '.csv');
        $this->fd = fopen($path, 'w+');

        if (!$this->fd) {
            $this->error('Unable to create export file');
            
            return -1;
        }
        // Imprimir cabecera
        $categories = Category::orderBy('id');
        $this->writeLine(array_merge(['Image'], $categories->pluck('name')->all()));        
        $categoriesCount = $categories->count();        
        // Imprimir filas
        $images = Image::orderBy('name')->get();
        $this->withProgressBar($images, function($image) use ($categoriesCount) {
            $a = [$image->name];

            foreach ($image->categories as $imageCategory) {
                $a[$imageCategory->id] = $imageCategory->pivot->value;
            }

            $this->writeLine($this->fillArray($a, $categoriesCount + 1));
        });
        
        fclose($this->fd);
        $this->line(PHP_EOL . 'Export completed!');
    }

    protected function writeLine($a)
    {
        fwrite($this->fd, '"' . implode('","', $a) . '"' . PHP_EOL);
    }    

    protected function fillArray($a, $n)
    {
        $r = [];

        for ($i = 0; $i < $n; $i++) { 
            $r[$i] = $a[$i] ?? '';
        }

        return $r;
    }
}

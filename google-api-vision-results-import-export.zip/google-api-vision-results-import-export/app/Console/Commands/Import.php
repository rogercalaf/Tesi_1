<?php

namespace App\Console\Commands;

use DB;
use Storage;
use Artisan;
use App\Models\Category;
use App\Models\Image;
use Illuminate\Console\Command;

class Import extends Command
{
    const INPUT_PATH = 'import/smallset';
    
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'app:import {--force : Force yes}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Import csv into database';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
        if (!$this->option('force') && !$this->confirm('Database data will be deleted. Are you sure?')) {
            return 0;
        }
        // Borrar tablas
        Artisan::call('migrate:fresh');
        // Leer ficheros
        $totalCount = 0;
        $files = Storage::files(static::INPUT_PATH);
        $this->withProgressBar($files, function($file) use (&$totalCount) {
            $path = storage_path('app/' . $file);
            $fd = fopen($path, 'r');

            if (!$fd) {
                $this->error('Unable to read import file');                
                
                return;
            }

            $categories = [];
            
            while (false !== ($cols = fgetcsv($fd, 1024 * 1024))) {                
                if (empty($cols[0])) {
                    continue;
                }
                
                if (strtolower($cols[0]) == 'image') {                    
                    for ($j = 1; $j < count($cols); $j++) { 
                        $category = Category::firstOrCreate(['name' => $cols[$j]]);
                        $categories[$j] = $category->id;
                    }                    
                }
                elseif (count($cols) > 1) {
                    $image = new Image;
                    $image->name = $cols[0];
                    $image->save();

                    for ($j = 1; $j < count($cols); $j++) { 
                        if (!empty(floatval($cols[$j]))) {
                            $image->categories()->attach($categories[$j], ['value' => $cols[$j], 'created_at' => now(), 'updated_at' => now()]);
                        }
                    }

                    $totalCount++;
                }
            }

            fclose($fd);
        });

        $this->line(PHP_EOL . $totalCount . ' images processed');
    }
}
